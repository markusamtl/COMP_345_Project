var _order_8h =
[
    [ "WarzoneOrder::TimeUtil", "class_warzone_order_1_1_time_util.html", null ],
    [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", "class_warzone_order_1_1_order" ],
    [ "WarzoneOrder::Deploy", "class_warzone_order_1_1_deploy.html", "class_warzone_order_1_1_deploy" ],
    [ "WarzoneOrder::Advance", "class_warzone_order_1_1_advance.html", "class_warzone_order_1_1_advance" ],
    [ "WarzoneOrder::Bomb", "class_warzone_order_1_1_bomb.html", "class_warzone_order_1_1_bomb" ],
    [ "WarzoneOrder::Blockade", "class_warzone_order_1_1_blockade.html", "class_warzone_order_1_1_blockade" ],
    [ "WarzoneOrder::Airlift", "class_warzone_order_1_1_airlift.html", "class_warzone_order_1_1_airlift" ],
    [ "WarzoneOrder::Negotiate", "class_warzone_order_1_1_negotiate.html", "class_warzone_order_1_1_negotiate" ],
    [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", "class_warzone_order_1_1_order_list" ],
    [ "WarzoneOrder::Territory", "class_warzone_order_1_1_territory.html", "class_warzone_order_1_1_territory" ],
    [ "WarzoneOrder::Map", "class_warzone_order_1_1_map.html", "class_warzone_order_1_1_map" ],
    [ "WarzoneOrder::Player", "class_warzone_order_1_1_player.html", "class_warzone_order_1_1_player" ],
    [ "WarzoneOrder::OrderType", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9", [
      [ "WarzoneOrder::OrderType::Deploy", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a507a3a88cebc46603ce2be8eaa924eee", null ],
      [ "WarzoneOrder::OrderType::Advance", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a0a86dddc699c7e6fe7f1e43153a5cbee", null ],
      [ "WarzoneOrder::OrderType::Bomb", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9acd3abfc2f377a4c3fd9181f919d9de82", null ],
      [ "WarzoneOrder::OrderType::Blockade", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9adefd317666a81fa7bddcb7e72d18e6cb", null ],
      [ "WarzoneOrder::OrderType::Airlift", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a9a7b0de022fc9d6581109ecaef72c956", null ],
      [ "WarzoneOrder::OrderType::Negotiate", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9ae481ddec4f99e1a01fa3c80225a2197c", null ]
    ] ]
];