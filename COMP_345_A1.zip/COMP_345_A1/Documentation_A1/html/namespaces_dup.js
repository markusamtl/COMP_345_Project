var namespaces_dup =
[
    [ "WarzoneCard", "namespace_warzone_card.html", "namespace_warzone_card" ],
    [ "WarzoneEngine", "namespace_warzone_engine.html", "namespace_warzone_engine" ],
    [ "WarzoneMap", "namespace_warzone_map.html", "namespace_warzone_map" ],
    [ "WarzoneOrder", "namespace_warzone_order.html", "namespace_warzone_order" ],
    [ "WarzonePlayer", "namespace_warzone_player.html", "namespace_warzone_player" ]
];