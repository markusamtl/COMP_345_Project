var NAVTREEINDEX8 =
{
"namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9acd3abfc2f377a4c3fd9181f919d9de82":[0,0,3,12,2],
"namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9adefd317666a81fa7bddcb7e72d18e6cb":[0,0,3,12,3],
"namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9ae481ddec4f99e1a01fa3c80225a2197c":[0,0,3,12,5],
"namespace_warzone_order.html#aa0c854d5fbf5feadbae0ae8ce8944a19":[0,0,3,14],
"namespace_warzone_order.html#aad97c6a06422271dc983699a7ea97229":[0,0,3,13],
"namespace_warzone_player.html":[0,0,4],
"namespace_warzone_player.html#a384a07e318d7b7fb7fa7ae81f690a48d":[0,0,4,10],
"namespace_warzone_player.html#a5fd96cb6607a530ca9c895b5714a914d":[0,0,4,11],
"namespacemembers.html":[0,1,0],
"namespacemembers_enum.html":[0,1,2],
"namespacemembers_func.html":[0,1,1],
"namespaces.html":[0,0],
"pages.html":[]
};
