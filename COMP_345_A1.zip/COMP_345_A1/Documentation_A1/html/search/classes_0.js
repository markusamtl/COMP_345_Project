var searchData=
[
  ['advance_0',['Advance',['../class_warzone_engine_1_1_advance.html',1,'WarzoneEngine::Advance'],['../class_warzone_order_1_1_advance.html',1,'WarzoneOrder::Advance']]],
  ['airlift_1',['Airlift',['../class_warzone_engine_1_1_airlift.html',1,'WarzoneEngine::Airlift'],['../class_warzone_order_1_1_airlift.html',1,'WarzoneOrder::Airlift']]]
];
