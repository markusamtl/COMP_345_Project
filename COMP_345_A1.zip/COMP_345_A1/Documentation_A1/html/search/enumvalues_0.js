var searchData=
[
  ['advance_0',['Advance',['../namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a0a86dddc699c7e6fe7f1e43153a5cbee',1,'WarzoneOrder']]],
  ['airlift_1',['Airlift',['../namespace_warzone_card.html#aab25376c0659189da418b78dc220a851a9a7b0de022fc9d6581109ecaef72c956',1,'WarzoneCard::Airlift'],['../namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a9a7b0de022fc9d6581109ecaef72c956',1,'WarzoneOrder::Airlift']]],
  ['assignreinforcement_2',['AssignReinforcement',['../namespace_warzone_engine.html#a5d285d45ace840f288f953f277b21fd3aac3583f18a7421aaffa7bf994e4d98eb',1,'WarzoneEngine']]]
];
