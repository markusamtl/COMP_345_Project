var searchData=
[
  ['deploy_0',['Deploy',['../namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a507a3a88cebc46603ce2be8eaa924eee',1,'WarzoneOrder']]],
  ['diplomacy_1',['Diplomacy',['../namespace_warzone_card.html#aab25376c0659189da418b78dc220a851ad38f4afc007ddb255c04f2d810fafaf5',1,'WarzoneCard']]]
];
