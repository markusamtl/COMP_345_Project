var indexSectionsWithContent =
{
  0: "abcdeghilmnoprstuvw~",
  1: "abcdghmnopst",
  2: "w",
  3: "cgmop",
  4: "abcdeghilmnoprstvw~",
  5: "eo",
  6: "ceo",
  7: "abdeimnpsuw",
  8: "o",
  9: "im"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

