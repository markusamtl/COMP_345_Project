var searchData=
[
  ['effect_0',['effect',['../class_warzone_order_1_1_order.html#a9229e7326e168bbc8a704c59133ee3fd',1,'WarzoneOrder::Order::effect'],['../class_warzone_card_1_1_order.html#a9229e7326e168bbc8a704c59133ee3fd',1,'WarzoneCard::Order::effect'],['../class_warzone_engine_1_1_order.html#a9229e7326e168bbc8a704c59133ee3fd',1,'WarzoneEngine::Order::effect'],['../class_warzone_player_1_1_order.html#a9229e7326e168bbc8a704c59133ee3fd',1,'WarzonePlayer::Order::effect']]]
];
