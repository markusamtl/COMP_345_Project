var _logging_observer_8h =
[
    [ "WarzoneLog::ILoggable", "class_warzone_log_1_1_i_loggable.html", "class_warzone_log_1_1_i_loggable" ],
    [ "WarzoneLog::Observer", "class_warzone_log_1_1_observer.html", "class_warzone_log_1_1_observer" ],
    [ "WarzoneLog::Subject", "class_warzone_log_1_1_subject.html", "class_warzone_log_1_1_subject" ],
    [ "WarzoneLog::LogObserver", "class_warzone_log_1_1_log_observer.html", "class_warzone_log_1_1_log_observer" ]
];