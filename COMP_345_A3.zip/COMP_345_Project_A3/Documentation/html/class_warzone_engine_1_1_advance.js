var class_warzone_engine_1_1_advance =
[
    [ "Advance", "class_warzone_engine_1_1_advance.html#a8da8562d6660011ae2554cee24f93f0d", null ],
    [ "Advance", "class_warzone_engine_1_1_advance.html#a501b4621c6f830ce58202e3dd6c9bf42", null ],
    [ "~Advance", "class_warzone_engine_1_1_advance.html#a0e23332d2fd724e23a51c86833641af3", null ],
    [ "clone", "class_warzone_engine_1_1_advance.html#a628d2cf1556e0a3916fbd1e7c485a1aa", null ],
    [ "execute", "class_warzone_engine_1_1_advance.html#a9e0671572db06ecbb598dbdf58173b34", null ],
    [ "getIssuer", "class_warzone_engine_1_1_advance.html#a3b6b45f41caf7fca87d1957cda844cf3", null ],
    [ "getNumArmies", "class_warzone_engine_1_1_advance.html#a81180974d4b2bc0795ecd6bad4ba1fd9", null ],
    [ "getSource", "class_warzone_engine_1_1_advance.html#a8f84944600e7e80f9668cb26b66e8201", null ],
    [ "getTarget", "class_warzone_engine_1_1_advance.html#a5d4b6f829b00b7d762a05bffd2ce613b", null ],
    [ "operator=", "class_warzone_engine_1_1_advance.html#a5b427a7cceb84e122a48e9b33a120263", null ],
    [ "print", "class_warzone_engine_1_1_advance.html#abedd75af7543b47ea3fc3b03211a4919", null ],
    [ "setIssuer", "class_warzone_engine_1_1_advance.html#a9a947d9dd513f41fff54bc27fd8bfaf4", null ],
    [ "setNumArmies", "class_warzone_engine_1_1_advance.html#ad260d595a11fedeb710b0948404a6b99", null ],
    [ "setSource", "class_warzone_engine_1_1_advance.html#afdf35f2e635e832ebd2ad421176f2fcb", null ],
    [ "setTarget", "class_warzone_engine_1_1_advance.html#a8e28701c12727985c568332142c6eb07", null ],
    [ "validate", "class_warzone_engine_1_1_advance.html#a31a37b3e35cf91c5c0b70558533bcb2f", null ]
];