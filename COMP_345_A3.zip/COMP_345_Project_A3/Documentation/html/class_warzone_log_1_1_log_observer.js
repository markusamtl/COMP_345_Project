var class_warzone_log_1_1_log_observer =
[
    [ "LogObserver", "class_warzone_log_1_1_log_observer.html#a5738815bdcf2e86ea9d58fb07e534077", null ],
    [ "~LogObserver", "class_warzone_log_1_1_log_observer.html#a4b0dd7b012e18f2d79665c7d9caee508", null ],
    [ "update", "class_warzone_log_1_1_log_observer.html#a2029d1621719541d8fb7c5f677e8df44", null ]
];