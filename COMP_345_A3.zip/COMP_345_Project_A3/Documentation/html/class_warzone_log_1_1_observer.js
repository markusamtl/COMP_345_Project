var class_warzone_log_1_1_observer =
[
    [ "Observer", "class_warzone_log_1_1_observer.html#ac53b0a7c6b8bcfed547b2aec3a57f7a3", null ],
    [ "~Observer", "class_warzone_log_1_1_observer.html#adfe216949657447c94d41e585d484890", null ],
    [ "update", "class_warzone_log_1_1_observer.html#a3c3f8ba25624120140467d6edf20b59d", null ]
];