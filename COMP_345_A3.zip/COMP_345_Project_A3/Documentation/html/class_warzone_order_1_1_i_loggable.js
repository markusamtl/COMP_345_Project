var class_warzone_order_1_1_i_loggable =
[
    [ "~ILoggable", "class_warzone_order_1_1_i_loggable.html#aefdc25c6ca6736e6100b407de0520c55", null ],
    [ "stringToLog", "class_warzone_order_1_1_i_loggable.html#a70b4e435cc49deeedca2a16c3644737d", null ]
];