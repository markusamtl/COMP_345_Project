var class_warzone_player_strategy_1_1_benevolent_player_strategy =
[
    [ "BenevolentPlayerStrategy", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#adf684fe7b93214c9617da560ac82882a", null ],
    [ "clone", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#a45a16c789417996fbb95b2b495e841c9", null ],
    [ "issueOrder", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#af62642881a403e913c46a44bb6be287b", null ],
    [ "toAttack", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#a8697ca9298cbc21350351bd7c639b110", null ],
    [ "toAttackString", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#a0888382a63e08ead48c646e262767485", null ],
    [ "toDefend", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#af5d7eb1579c4950da5a55e78822d4fad", null ],
    [ "toDefendString", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html#ac1c193cc2a218956eba4cb519d299c48", null ]
];