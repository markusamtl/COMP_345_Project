var class_warzone_player_strategy_1_1_human_player_strategy =
[
    [ "HumanPlayerStrategy", "class_warzone_player_strategy_1_1_human_player_strategy.html#a07215b24eb2fa6e6d40afb50b3fee727", null ],
    [ "clone", "class_warzone_player_strategy_1_1_human_player_strategy.html#a2fc4af77ba493c885bd4e24cca835731", null ],
    [ "issueOrder", "class_warzone_player_strategy_1_1_human_player_strategy.html#ae234db2cabdb1cf7bf48cc3c81df704f", null ],
    [ "toAttack", "class_warzone_player_strategy_1_1_human_player_strategy.html#a306ccc55e4e6faf525b4a4216c8f78e6", null ],
    [ "toAttackString", "class_warzone_player_strategy_1_1_human_player_strategy.html#a162e3c5938e99e8c40d56e4eeb075157", null ],
    [ "toDefend", "class_warzone_player_strategy_1_1_human_player_strategy.html#ad0f67b83c95671b882a354f3407f1959", null ],
    [ "toDefendString", "class_warzone_player_strategy_1_1_human_player_strategy.html#abbaf286de7aabd5cc402a09cc1b3c1f7", null ]
];