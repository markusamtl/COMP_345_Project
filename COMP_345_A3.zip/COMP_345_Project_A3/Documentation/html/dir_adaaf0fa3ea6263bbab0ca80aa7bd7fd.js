var dir_adaaf0fa3ea6263bbab0ca80aa7bd7fd =
[
    [ "LoggingObserver.cpp", "_logging_observer_8cpp.html", "_logging_observer_8cpp" ],
    [ "LoggingObserver.h", "_logging_observer_8h.html", "_logging_observer_8h" ],
    [ "LoggingObserverDriver.cpp", "_logging_observer_driver_8cpp.html", "_logging_observer_driver_8cpp" ],
    [ "LoggingObserverDriver.h", "_logging_observer_driver_8h.html", "_logging_observer_driver_8h" ]
];