var hierarchy =
[
    [ "WarzoneCard::Card", "class_warzone_card_1_1_card.html", null ],
    [ "WarzoneEngine::Card", "class_warzone_engine_1_1_card.html", null ],
    [ "WarzonePlayer::Card", "class_warzone_player_1_1_card.html", null ],
    [ "WarzoneMap::Continent", "class_warzone_map_1_1_continent.html", null ],
    [ "WarzonePlayer::Continent", "class_warzone_player_1_1_continent.html", null ],
    [ "WarzoneCard::Deck", "class_warzone_card_1_1_deck.html", null ],
    [ "WarzoneEngine::Deck", "class_warzone_engine_1_1_deck.html", null ],
    [ "WarzonePlayer::Deck", "class_warzone_player_1_1_deck.html", null ],
    [ "WarzoneCard::Hand", "class_warzone_card_1_1_hand.html", null ],
    [ "WarzoneEngine::Hand", "class_warzone_engine_1_1_hand.html", null ],
    [ "WarzonePlayer::Hand", "class_warzone_player_1_1_hand.html", null ],
    [ "WarzoneCommand::ILoggable", "class_warzone_command_1_1_i_loggable.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", [
        [ "WarzoneCommand::FileCommandProcessorAdapter", "class_warzone_command_1_1_file_command_processor_adapter.html", null ]
      ] ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", [
        [ "WarzoneOrder::Advance", "class_warzone_order_1_1_advance.html", null ],
        [ "WarzoneOrder::Airlift", "class_warzone_order_1_1_airlift.html", null ],
        [ "WarzoneOrder::Blockade", "class_warzone_order_1_1_blockade.html", null ],
        [ "WarzoneOrder::Bomb", "class_warzone_order_1_1_bomb.html", null ],
        [ "WarzoneOrder::Deploy", "class_warzone_order_1_1_deploy.html", null ],
        [ "WarzoneOrder::Negotiate", "class_warzone_order_1_1_negotiate.html", null ]
      ] ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneEngine::ILoggable", "class_warzone_engine_1_1_i_loggable.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneLog::ILoggable", "class_warzone_log_1_1_i_loggable.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneOrder::ILoggable", "class_warzone_order_1_1_i_loggable.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneMap::Map", "class_warzone_map_1_1_map.html", null ],
    [ "WarzoneOrder::Map", "class_warzone_order_1_1_map.html", null ],
    [ "WarzoneMap::MapLoader", "class_warzone_map_1_1_map_loader.html", null ],
    [ "WarzoneLog::Observer", "class_warzone_log_1_1_observer.html", [
      [ "WarzoneLog::LogObserver", "class_warzone_log_1_1_log_observer.html", null ]
    ] ],
    [ "WarzoneCard::Player", "class_warzone_card_1_1_player.html", null ],
    [ "WarzoneEngine::Player", "class_warzone_engine_1_1_player.html", null ],
    [ "WarzoneMap::Player", "class_warzone_map_1_1_player.html", null ],
    [ "WarzoneOrder::Player", "class_warzone_order_1_1_player.html", null ],
    [ "WarzonePlayer::Player", "class_warzone_player_1_1_player.html", null ],
    [ "WarzonePlayer::PlayerStrategy", "class_warzone_player_1_1_player_strategy.html", [
      [ "WarzonePlayerStrategy::AggressivePlayerStrategy", "class_warzone_player_strategy_1_1_aggressive_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::BenevolentPlayerStrategy", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::CheaterPlayerStrategy", "class_warzone_player_strategy_1_1_cheater_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::HumanPlayerStrategy", "class_warzone_player_strategy_1_1_human_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::NeutralPlayerStrategy", "class_warzone_player_strategy_1_1_neutral_player_strategy.html", null ]
    ] ],
    [ "WarzonePlayerStrategy::PlayerStrategy", "class_warzone_player_strategy_1_1_player_strategy.html", [
      [ "WarzonePlayerStrategy::AggressivePlayerStrategy", "class_warzone_player_strategy_1_1_aggressive_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::BenevolentPlayerStrategy", "class_warzone_player_strategy_1_1_benevolent_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::CheaterPlayerStrategy", "class_warzone_player_strategy_1_1_cheater_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::HumanPlayerStrategy", "class_warzone_player_strategy_1_1_human_player_strategy.html", null ],
      [ "WarzonePlayerStrategy::NeutralPlayerStrategy", "class_warzone_player_strategy_1_1_neutral_player_strategy.html", null ]
    ] ],
    [ "WarzoneEngine::PlayerTerrContainer", "class_warzone_engine_1_1_player_terr_container.html", null ],
    [ "WarzonePlayer::PlayerTerrContainer", "class_warzone_player_1_1_player_terr_container.html", null ],
    [ "WarzoneCommand::StringHandling", "class_warzone_command_1_1_string_handling.html", null ],
    [ "WarzoneMap::StringHandling", "class_warzone_map_1_1_string_handling.html", null ],
    [ "WarzoneCommand::Subject", "class_warzone_command_1_1_subject.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneEngine::Subject", "class_warzone_engine_1_1_subject.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneLog::Subject", "class_warzone_log_1_1_subject.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneOrder::Subject", "class_warzone_order_1_1_subject.html", [
      [ "WarzoneCommand::Command", "class_warzone_command_1_1_command.html", null ],
      [ "WarzoneCommand::CommandProcessor", "class_warzone_command_1_1_command_processor.html", null ],
      [ "WarzoneEngine::GameEngine", "class_warzone_engine_1_1_game_engine.html", null ],
      [ "WarzoneOrder::Order", "class_warzone_order_1_1_order.html", null ],
      [ "WarzoneOrder::OrderList", "class_warzone_order_1_1_order_list.html", null ]
    ] ],
    [ "WarzoneMap::Territory", "class_warzone_map_1_1_territory.html", null ],
    [ "WarzoneOrder::Territory", "class_warzone_order_1_1_territory.html", null ],
    [ "WarzonePlayer::Territory", "class_warzone_player_1_1_territory.html", null ],
    [ "TimeUtil", "class_time_util.html", null ],
    [ "WarzoneCard::TimeUtil", "class_warzone_card_1_1_time_util.html", null ],
    [ "WarzoneEngine::TimeUtil", "class_warzone_engine_1_1_time_util.html", null ],
    [ "WarzoneMap::TimeUtil", "class_warzone_map_1_1_time_util.html", null ],
    [ "WarzoneOrder::TimeUtil", "class_warzone_order_1_1_time_util.html", null ],
    [ "WarzonePlayer::TimeUtil", "class_warzone_player_1_1_time_util.html", null ]
];