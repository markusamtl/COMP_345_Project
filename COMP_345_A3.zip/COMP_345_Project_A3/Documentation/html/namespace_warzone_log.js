var namespace_warzone_log =
[
    [ "ILoggable", "class_warzone_log_1_1_i_loggable.html", "class_warzone_log_1_1_i_loggable" ],
    [ "LogObserver", "class_warzone_log_1_1_log_observer.html", "class_warzone_log_1_1_log_observer" ],
    [ "Observer", "class_warzone_log_1_1_observer.html", "class_warzone_log_1_1_observer" ],
    [ "Subject", "class_warzone_log_1_1_subject.html", "class_warzone_log_1_1_subject" ]
];