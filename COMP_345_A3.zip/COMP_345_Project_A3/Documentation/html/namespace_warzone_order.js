var namespace_warzone_order =
[
    [ "Advance", "class_warzone_order_1_1_advance.html", "class_warzone_order_1_1_advance" ],
    [ "Airlift", "class_warzone_order_1_1_airlift.html", "class_warzone_order_1_1_airlift" ],
    [ "Blockade", "class_warzone_order_1_1_blockade.html", "class_warzone_order_1_1_blockade" ],
    [ "Bomb", "class_warzone_order_1_1_bomb.html", "class_warzone_order_1_1_bomb" ],
    [ "Deploy", "class_warzone_order_1_1_deploy.html", "class_warzone_order_1_1_deploy" ],
    [ "ILoggable", "class_warzone_order_1_1_i_loggable.html", "class_warzone_order_1_1_i_loggable" ],
    [ "Map", "class_warzone_order_1_1_map.html", "class_warzone_order_1_1_map" ],
    [ "Negotiate", "class_warzone_order_1_1_negotiate.html", "class_warzone_order_1_1_negotiate" ],
    [ "Order", "class_warzone_order_1_1_order.html", "class_warzone_order_1_1_order" ],
    [ "OrderList", "class_warzone_order_1_1_order_list.html", "class_warzone_order_1_1_order_list" ],
    [ "Player", "class_warzone_order_1_1_player.html", "class_warzone_order_1_1_player" ],
    [ "Subject", "class_warzone_order_1_1_subject.html", "class_warzone_order_1_1_subject" ],
    [ "Territory", "class_warzone_order_1_1_territory.html", "class_warzone_order_1_1_territory" ],
    [ "TimeUtil", "class_warzone_order_1_1_time_util.html", null ],
    [ "OrderType", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9", [
      [ "Deploy", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a507a3a88cebc46603ce2be8eaa924eee", null ],
      [ "Advance", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a0a86dddc699c7e6fe7f1e43153a5cbee", null ],
      [ "Bomb", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9acd3abfc2f377a4c3fd9181f919d9de82", null ],
      [ "Blockade", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9adefd317666a81fa7bddcb7e72d18e6cb", null ],
      [ "Airlift", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9a9a7b0de022fc9d6581109ecaef72c956", null ],
      [ "Negotiate", "namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9ae481ddec4f99e1a01fa3c80225a2197c", null ]
    ] ],
    [ "PlayerStrategyType", "namespace_warzone_order.html#ab0ea443e5000addc7ef21f4bbcf8b19c", null ],
    [ "operator<<", "namespace_warzone_order.html#aad97c6a06422271dc983699a7ea97229", null ],
    [ "operator<<", "namespace_warzone_order.html#aa0c854d5fbf5feadbae0ae8ce8944a19", null ]
];