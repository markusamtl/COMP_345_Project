var searchData=
[
  ['unknown_0',['Unknown',['../namespace_warzone_card.html#aab25376c0659189da418b78dc220a851a88183b946cc5f0e8c96b2e66e1c74a7e',1,'WarzoneCard']]],
  ['update_1',['update',['../class_warzone_log_1_1_observer.html#a3c3f8ba25624120140467d6edf20b59d',1,'WarzoneLog::Observer::update()'],['../class_warzone_log_1_1_log_observer.html#a2029d1621719541d8fb7c5f677e8df44',1,'WarzoneLog::LogObserver::update()']]]
];
