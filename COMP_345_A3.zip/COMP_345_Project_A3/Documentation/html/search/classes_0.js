var searchData=
[
  ['advance_0',['Advance',['../class_warzone_engine_1_1_advance.html',1,'WarzoneEngine::Advance'],['../class_warzone_order_1_1_advance.html',1,'WarzoneOrder::Advance']]],
  ['aggressiveplayerstrategy_1',['AggressivePlayerStrategy',['../class_warzone_player_strategy_1_1_aggressive_player_strategy.html',1,'WarzonePlayerStrategy']]],
  ['airlift_2',['Airlift',['../class_warzone_engine_1_1_airlift.html',1,'WarzoneEngine::Airlift'],['../class_warzone_order_1_1_airlift.html',1,'WarzoneOrder::Airlift']]]
];
