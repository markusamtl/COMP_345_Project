var searchData=
[
  ['logobserver_0',['LogObserver',['../class_warzone_log_1_1_log_observer.html',1,'WarzoneLog']]]
];
