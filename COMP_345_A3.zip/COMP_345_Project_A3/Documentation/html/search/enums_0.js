var searchData=
[
  ['cardtype_0',['CardType',['../namespace_warzone_card.html#aab25376c0659189da418b78dc220a851',1,'WarzoneCard::CardType'],['../namespace_warzone_engine.html#aab25376c0659189da418b78dc220a851',1,'WarzoneEngine::CardType']]]
];
