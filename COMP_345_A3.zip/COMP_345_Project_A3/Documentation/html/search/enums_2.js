var searchData=
[
  ['ordertype_0',['OrderType',['../namespace_warzone_order.html#a5ffce4f192c940e5f3c1f9d36993a0c9',1,'WarzoneOrder::OrderType'],['../namespace_warzone_engine.html#a5ffce4f192c940e5f3c1f9d36993a0c9',1,'WarzoneEngine::OrderType']]]
];
