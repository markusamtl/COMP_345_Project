var searchData=
[
  ['update_0',['update',['../class_warzone_log_1_1_observer.html#a3c3f8ba25624120140467d6edf20b59d',1,'WarzoneLog::Observer::update()'],['../class_warzone_log_1_1_log_observer.html#a2029d1621719541d8fb7c5f677e8df44',1,'WarzoneLog::LogObserver::update()']]]
];
