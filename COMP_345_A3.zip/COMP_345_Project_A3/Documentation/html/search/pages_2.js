var searchData=
[
  ['summary_0',['Algorithm Summary',['../class_warzone_map_1_1_string_handling.html#autotoc_md0',1,'']]]
];
