var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw~",
  1: "abcdfghilmnopst",
  2: "w",
  3: "cglmopt",
  4: "abcdefghilmnoprstuv~",
  5: "aegilmoqrsv",
  6: "ceop",
  7: "abcdehimnpsuw",
  8: "o",
  9: "im",
  10: "abs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Pages"
};

