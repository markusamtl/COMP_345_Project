var searchData=
[
  ['ordertype_0',['orderType',['../class_warzone_order_1_1_order.html#ae7ad019cb82ec053ae9f2adb09848ef0',1,'WarzoneOrder::Order::orderType'],['../class_warzone_card_1_1_order.html#ae7ad019cb82ec053ae9f2adb09848ef0',1,'WarzoneCard::Order::orderType'],['../class_warzone_engine_1_1_order.html#ae7ad019cb82ec053ae9f2adb09848ef0',1,'WarzoneEngine::Order::orderType'],['../class_warzone_player_1_1_order.html#ae7ad019cb82ec053ae9f2adb09848ef0',1,'WarzonePlayer::Order::orderType']]]
];
