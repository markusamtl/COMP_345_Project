var searchData=
[
  ['strategytype_0',['strategyType',['../class_warzone_player_strategy_1_1_player_strategy.html#abe2ed6b0821808bf3150cfe13abcd8fc',1,'WarzonePlayerStrategy::PlayerStrategy::strategyType'],['../class_warzone_player_1_1_player_strategy.html#abe2ed6b0821808bf3150cfe13abcd8fc',1,'WarzonePlayer::PlayerStrategy::strategyType']]]
];
